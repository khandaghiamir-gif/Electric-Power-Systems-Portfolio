function [Asys] = linearization(gen,V,Emf,Xd,H,D_g,Ybus,f)
%     Ybus = full(Ybus);
    %   
    disp('---------------------------');
    disp('Starting the modal analysis');
    %% pre-define all variables
    % ================= machine data =========================
    len_mac = size(gen,1);
    mac_indx = gen(:,1);
    nbus = size(V,1);

    wB = 2*pi*f; % base frequency in rad/s
    M = 2.*H/wB;
    %% ============== calculate initial condition ============
    % compute vd vq
    vd = abs(V(mac_indx)).*cos(angle(V(mac_indx)));
    vq = abs(V(mac_indx)).*sin(angle(V(mac_indx)));
    %%  partial derivatives of power
    % derivative of Pe with deltas
    dPedd = abs(Emf)./Xd.*vq.*sin(angle(Emf))+abs(Emf)./Xd.*vd.*cos(angle(Emf));

    % derivative of Pe with vd and vq
    dPedvd = abs(Emf)./Xd.*sin(angle(Emf));
    dPedvq = -abs(Emf)./Xd.*cos(angle(Emf));

    % derivative of Norton currents with deltas
    didd = abs(Emf)./Xd.*cos(angle(Emf));
    didq = abs(Emf)./Xd.*sin(angle(Emf));
    % ============ end initial condition calculation =======
    disp('All the initial values has been calculated');
    disp('------------------------------------');
    disp('Eig analysis');
    %% ========= get state space representation ============
    A1 = [];
    A2 = [];
    A3 = [];

    BY = imag(Ybus);
    GY = real(Ybus);

    for jj = 1:nbus % A4 matrix
        for ii = 1:nbus
            A4(2*(jj-1)+1,2*(ii-1)+1) = GY(jj,ii);
            A4(2*(jj-1)+1,2*ii) = -BY(jj,ii);
            A4(2*jj,2*(ii-1)+1) = BY(jj,ii);
            A4(2*jj,2*ii) = GY(jj,ii);
        end
    end

    for k = 1:len_mac
        i = mac_indx(k);
        % only 2 equations - A1
        A1i = [
            0                    1      ;     %delta 
            -dPedd(i)/M(i)  -D_g(i)/M(i);     %w
            ];
        % A2
        A2i = [
                 0                 0          ;                                       
           -dPedvd(i)/M(i)   -dPedvq(i)/M(i)  ; 
            ];
        % A3
        A3i =[
            -didd(i) 0 ; 
            -didq(i) 0 ;
            ];

        A1 = blkdiag(A1, A1i);
        A2 = blkdiag(A2, A2i);
        A3 = blkdiag(A3, A3i);
    end
    % Get Asys
    A2(2*len_mac,nbus*2) = 0;
    A3(nbus*2,2*len_mac) = 0;
    Asys = A1-A2*inv(A4)*A3;
end

