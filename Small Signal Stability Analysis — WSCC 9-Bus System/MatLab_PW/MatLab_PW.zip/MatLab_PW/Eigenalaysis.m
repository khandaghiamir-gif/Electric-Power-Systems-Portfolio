clc;
clear all;
close all;
warning off;
path(path,'Load_flow'); % adding the folder with the LF functions
%% Copyright Andrea Vicario %%%%
%% start - grid selection
% WSCC - 9 bus test system
% results are coherent with Digsilent - 2nd order machine model
grid_name = 'Grid_WSCC_Sauer'; % grid - Only static data, no losses grid
baseMVA = 100; % base

% generators data --> G1 - G2 - G3
Xd = [0.146;0.8958;1.3125]; % generator transient reactance G1 - G2 - G3
H = [25.32;5.2;2.98]; % inertia G1 - G2 - G3
D_g = [0.00; 0.00; 0.00]; % damping G1 - G2 - G3

f = 50; % nominal frequency
w_0 = 2*pi*f;

% steady state conditions
[gen,Voltages,Emf,Ybus] = LF(grid_name,Xd,baseMVA); % run the load flow and compute Ybus
%% Get A matrix: HP: g=0 for generators
[Asys] = linearization(gen,Voltages,Emf,Xd,H,D_g,Ybus,f); % A matrix

[V,eigenvalues] = eig(Asys); % eigenalaysis
W = inv(V).'; % left eigenvectors
% test, the result is an unitary matrix: W*V.' = I
% help: A.' returns the nonconjugate transpose of A

lambda = diag(round(eigenvalues,2)); % eigenvalues
cx = find(imag(lambda)); % taking only the oscillatory modes
lambda_o = lambda(cx); % taking only the oscillatory modes
% taking only one eig./mode since they are complex-conjugate
damping = round(-real(lambda_o(1:2:end))./abs(lambda_o(1:2:end)),3) % damping
frequency = abs(imag(lambda_o(1:2:end)/(2*pi))) % frequency

part_fact = W.*V; % participation factors(normalized --> sum = 1)
part_fact_o = part_fact(:,cx); % select the participation factors of the oscillatory modes
part_fact_n = abs(part_fact_o)./abs(max(part_fact_o)); % participation factors (normalized)
%% figures for modal analysis - normalized mode shapes
ngen = size(gen,1); % number of generators
for i = 1:ngen % names
   label = sprintf('Gen%i',i); % labels
   name_gen{i} = label;
end    

for i = 1:ngen % names
   label_1(i,:) = sprintf('Delta %i',i); % labels
   label_2(i,:) = sprintf('Omega %i',i); % labels
end   
state_var = zeros(ngen*2,length(label_1));
state_var(1:2:end,:) = label_1;
state_var(2:2:end,:) = label_2; % state variables needed

n = [0 0 1; 1 0 0; 0 1 0]; % color settings according to PowerWorld

figure % first oscillatory mode
C = compass(V([2 4 6],1)./abs(max(V([2 4 6],1)))); % take the speed index --> position 2 4 6 for the rows
for k = 1:ngen % add the color
        C(k).Color = n(k,:);
end
legend(name_gen);
title('Mode shape - first mode')

figure % second oscillatory mode
C = compass(V([2 4 6],3)./abs(max(V([2 4 6],3)))); % take the speed index --> position 2 4 6 for the rows
for k = 1:ngen % add the color
        C(k).Color = n(k,:);
end
legend(name_gen);
title('Mode shape - second mode')

% plot the eigenvalues in the complex space
figure
plot(real(round(lambda,3)),imag(lambda),'xw','MarkerSize',12,'Markeredgecolor',[0,0,1],'LineWidth',2.5);
grid on
xlabel('Real'); ylabel('Imag'); title('Complex space');
legend('DG1=0')

% plot the participation factors of the oscillatory modes
figure
bar(part_fact_n(:,1:2:end)');
xlabel('Modes'); ylabel('Magnitude'); title('Participation factors');
legend(char(state_var))